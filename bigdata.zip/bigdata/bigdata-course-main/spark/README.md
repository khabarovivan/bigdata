https://www.informit.com/articles/article.aspx?p=2928186

https://towardsdatascience.com/diy-apache-spark-docker-bb4f11c10d24

https://shortcut.com/developer-how-to/how-to-set-up-a-hadoop-cluster-in-docker

https://marcel-jan.eu/datablog/2020/10/25/i-built-a-working-hadoop-spark-hive-cluster-on-docker-here-is-how/

https://kubernetes.io/ru/docs/tasks/tools/install-minikube/