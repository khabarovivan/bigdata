Spark standalone docker compose with airflow:
https://github.com/cordon-thiago/airflow-spark/blob/master/docker/docker-compose.yml